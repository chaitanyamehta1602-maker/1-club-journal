# 1% Circle — Trading Journal

## Files
- `index.html` — dashboard, trade entry form, filters, history.
- `styles.css` — responsive dark/minimal interface.
- `app.js` — local data store, metrics, charts, CSV import/export and JSON backup.
- `sample_mt5_history.csv` — sample CSV layout for testing.

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. Keep an internet connection for Chart.js (charts) and Google Fonts. The journal itself runs client-side.
4. For best results, serve the folder using VS Code Live Server or another static web server.

## Current functionality
- Multiple named accounts and account/strategy/mode/date filters.
- Manual and algo trade records.
- Entry/exit timestamps and prices, symbol, side, size, SL/TP, net P&L, optional cash risk and calculated R-multiple.
- Notes, setup/session field and optional chart screenshot.
- Equity curve, strategy P&L, win rate, profit factor, expectancy and trade-based peak-to-trough drawdown.
- CSV trade export and JSON backup.
- MT5 CSV import for common exports with columns such as `Symbol`, `Type`, `Price`, `Volume`, `Profit`, and `Time`/`Date`.

## Important MT5 import limitation
MT5 history exports can contain separate deal rows for opening and closing, partial closes, commissions, swaps and balance operations. This basic importer imports matching rows individually; it does **not** reliably reconstruct full positions across every MT5 report format. Check for duplicate/opening rows and reconcile imported net P&L against the MT5 account statement before relying on analytics. A production-grade importer should aggregate by position ID and calculate net P&L from profit + commission + swap + fees, using the exact export format from your broker.

## Data and privacy
This is a **local-first prototype**, not a hosted multi-user service. Trade data is stored in browser `localStorage` on the current browser/device. Clearing site data can delete records; export JSON backups regularly. Screenshot storage is limited by browser quota. No login, cloud sync, encryption, database, or server-side backup is included.

## Metrics definitions
- Net P&L: sum of the recorded net P&L values. Enter P&L after commissions/swaps/fees for accurate results.
- R-multiple: net P&L divided by the optional cash risk amount.
- Profit factor: gross winning P&L divided by absolute gross losing P&L.
- Max drawdown: largest peak-to-trough decline in the cumulative sequence of logged trades, starting from zero. It is not account-equity drawdown unless all balance/equity cash flows are also modelled.
- Expectancy: average net P&L per logged trade.

## Recommended next steps before real use
1. Confirm the exact MT5 CSV export format from your broker and implement position-level aggregation.
2. Add currency selection per account and correct FX conversion if accounts use different currencies.
3. Add edit trade, screenshot storage via IndexedDB, and data validation.
4. For a deployed website with secure logins and cross-device access, add a backend (e.g. Supabase/PostgreSQL), authentication, row-level security and scheduled backups.
